
</section>
</section>
<!--main content end-->
</section>
<!-- Placed js at the end of the document so the pages load faster -->
<!--Core js-->
<script src="<?= base_url() ?>assets/js/jquery.js"></script>
<script src="<?= base_url() ?>assets/js/jquery-ui/jquery-ui-1.10.1.custom.min.js"></script>
<script src="<?= base_url() ?>assets/bs3/js/bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.scrollTo.min.js"></script>
<script src="<?= base_url() ?>assets/js/jQuery-slimScroll-1.3.0/jquery.slimscroll.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.nicescroll.js"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="<?= base_url() ?>assets/js/skycons/skycons.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.scrollTo/jquery.scrollTo.js"></script>
<script src="<?= base_url() ?>assets/js/jquery.easing.min.js"></script>
<script src="<?= base_url() ?>assets/js/calendar/clndr.js"></script>
<script src="<?= base_url() ?>assets/js/underscore-min.js"></script>
<script src="<?= base_url() ?>assets/js/calendar/moment-2.2.1.js"></script>
<script src="<?= base_url() ?>assets/js/evnt.calendar.init.js"></script>
<script src="<?= base_url() ?>assets/js/jvector-map/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?= base_url() ?>assets/js/jvector-map/jquery-jvectormap-us-lcc-en.js"></script>
<!-- Custom JS -->
<?php if(isset($custom_js)) echo $custom_js; ?>
<script src="<?= base_url() ?>assets/js/jquery.customSelect.min.js" ></script>
<!--common script init for all pages-->
<script src="<?= base_url() ?>assets/js/scripts.js"></script>
<!--script for this page-->
</body>
</html>